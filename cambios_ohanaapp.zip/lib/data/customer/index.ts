
// Re-export all customer-related functionality from this barrel file
export * from './customerService';
export * from './valetService';
export * from './loyaltyService';
export * from './customerRetrievalService';
export * from './customerStorageService';
export * from './phoneUtils';
